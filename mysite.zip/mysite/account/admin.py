from django.contrib import admin
from account.models import  EmailConfirmation

admin.site.register(EmailConfirmation)
